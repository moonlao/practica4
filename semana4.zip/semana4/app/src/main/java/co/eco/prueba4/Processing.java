package co.eco.prueba4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class Processing extends AppCompatActivity {

    private ListView ipList;
    private Button backBtn;

    private ArrayList<String> pingsList = new ArrayList<String>();
    private ArrayAdapter<String> adapter;

    private String userIP;
    private boolean ipType;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_processing);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, pingsList);

        ipList= findViewById(R.id.ipList);
        backBtn= findViewById(R.id.backBtn);

        ipType=getIntent().getExtras().getBoolean("typeIP");
        userIP= getIntent().getExtras().getString("userIP");

        if (ipType==true){

            pinged();
        }else{

            hosts();
        }

        backBtn.setOnClickListener(

                v->{

                    finish();
                }

        );
    }

    public void pinged() {

        new Thread(

                () -> {

                    try {

                        String myIp = userIP;

                        String otherIP;

                        InetAddress inet = InetAddress.getByName(myIp);

                        for (int i = 0; i <= 5; i++) {
                            boolean link = inet.isReachable(1000);
                            runOnUiThread(

                                    ()->{

                                        pingsList.add("Conectado: " + link);
                                        adapter.notifyDataSetChanged();
                                        ipList.setAdapter(adapter);

                                    }

                            );

                            Log.e(">>>", "Conectado: " + link);
                        }

                    } catch (UnknownHostException e) {
                        e.printStackTrace();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

        ).start();
    }

    public void hosts(){

        new Thread(

                ()->{

                    String predetermined = "192.168.1.";

                    for (int i = 0; i<255; i++){
                        String ip = predetermined+i;

                        try {
                            InetAddress inet = InetAddress.getByName(ip);
                            boolean linked = inet.isReachable(1000);
                            if (linked){

                                runOnUiThread(

                                        ()->{

                                            pingsList.add("IP's: " + ip);
                                            adapter.notifyDataSetChanged();
                                            ipList.setAdapter(adapter);

                                        }
                                );

                                Log.e(">>>", "Conectado: " + ip);

                            }

                        } catch (UnknownHostException e) {
                            e.printStackTrace();

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

        ).start();
    }
}