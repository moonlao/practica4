package co.eco.prueba4;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    private ConstraintLayout screen1;

    private EditText pt1, pt2, pt3, pt4;

    private Button pingBtn, findHostBtn;

    private TextView myIP;
    private boolean validate, ipType;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        screen1 = findViewById(R.id.screen1);

        pt1 = findViewById(R.id.pt1);
        pt2 = findViewById(R.id.pt2);
        pt3 = findViewById(R.id.pt3);
        pt4 = findViewById(R.id.pt4);

        pingBtn = findViewById(R.id.pingBtn);

        findHostBtn = findViewById(R.id.findHostBtn);
        myIP = findViewById(R.id.myIP);

        validate = false;

        myIP.setText("192.168.1.2");

        pingedBtn();
        findHostsBtn();


    }


    public void pingedBtn(){

        pingBtn.setOnClickListener(

                v -> {

                    validate = true;

                    String ipPt1= pt1.getText().toString();
                    String ipPt2 = pt2.getText().toString();
                    String ipPt3 = pt3.getText().toString();
                    String ipPt4 = pt4.getText().toString();

                    String[] stitchIp = new String[]{

                            ipPt1, ipPt2, ipPt3, ipPt4

                    };

                    if (validate) {
                        for (int i = 0; i < stitchIp.length; i++) {

                            if (stitchIp[i] == null || stitchIp[i].isEmpty()) {
                                Toast.makeText(this, "value input", Toast.LENGTH_LONG).show();

                                validate = false;

                            }
                        }
                    }


                    if (validate == true) {
                        String wholeIP = ipPt1 + "." + ipPt2 + "." + ipPt3 + "." + ipPt4;
                        Log.e(">>>", "IP: " + wholeIP);

                        Intent i = new Intent(this, Processing.class);
                        ipType = true;
                        i.putExtra("IP Type", ipType);
                        i.putExtra("IP User", wholeIP);
                        startActivity(i);

                        pt1.setText("");
                        pt2.setText("");
                        pt3.setText("");
                        pt4.setText("");
                    }


                }
        );
    }

    public void findHostsBtn() {

        findHostBtn.setOnClickListener(

                v -> {

                    validate = true;

                    String ipPt1= pt1.getText().toString();
                    String ipPt2 = pt2.getText().toString();
                    String ipPt3 = pt3.getText().toString();

                    String[] stitchIP = new String[]{
                            ipPt1, ipPt2, ipPt3
                    };

                    if (validate) {

                        for (int i = 0; i < stitchIP.length; i++) {

                            if (stitchIP[i] == null || stitchIP[i].isEmpty()) {
                                Toast.makeText(this, "inpput value", Toast.LENGTH_LONG).show();
                                validate = false;
                            }
                        }
                    }

                    if (validate == true) {

                        String wholeIP = ipPt1 + "." + ipPt2 + "." + ipPt3;
                        Log.e(">>>", "IP: " + wholeIP);

                        Intent i = new Intent(this, Processing.class);

                        ipType = false;

                        i.putExtra("type", ipType);
                        i.putExtra("user", wholeIP);

                        startActivity(i);

                        pt1.setText("");
                        pt2.setText("");
                        pt3.setText("");
                        pt4.setText("");

                    }
                }
        );

    }

}